# Crypto Hunter AI — başlangıç prototipi

Bu sürüm Binance USDⓈ-M Futures'ın herkese açık piyasa verilerini kullanır; API anahtarı ve Binance hesabı bağlantısı gerekmez. Otomatik emir göndermez.

## Çalıştırma
1. Python 3.10+ kurulu bir bilgisayarda terminal aç.
2. Proje klasöründe:
   `pip install -r requirements.txt`
3. Uygulamayı başlat:
   `streamlit run app.py`
4. Terminalde gösterilen yerel adresi aç. Aynı Wi-Fi'daki telefondan erişim için ayrıca ağ ayarı gerekebilir.

## iPhone'dan erişim
iPhone'da Safari üzerinden kullanmak için uygulamanın internete açık bir Streamlit barındırma hizmetine veya kendi sunucuna dağıtılması gerekir. Bu dosya tek başına iPhone'da 7/24 çalışan servis değildir.

## Önemli notlar
- Sinyal puanı olasılık tahmini değildir.
- Giriş/stop/TP seviyeleri ATR tabanlı örnek referanslardır; kesin emir önerisi değildir.
- Bu prototip bazı göstergeleri ve piyasa verilerini kullanır; likidasyon haritası, gerçek zamanlı order book dengesizliği, geçmiş OI serisi ve kapsamlı geriye dönük test henüz eklenmemiştir.
- Gerçek para ile işlem yapmadan önce backtest ve demo/paper trading yapılmalıdır.
- Binance API kullanım sınırları ve erişilebilirlik bölgeye göre değişebilir.
